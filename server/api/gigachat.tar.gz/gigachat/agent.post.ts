import { AgentExecutor, createStructuredChatAgent } from "langchain/agents";
import { DynamicTool } from "langchain/tools";
import { AIMessage, HumanMessage } from "@langchain/core/messages";
import { PromptTemplate } from "@langchain/core/prompts";
import { getModel } from "../../utils/aiAgent";
import { useRedis } from "../../utils/redis";
import { createReactAgent } from "langchain/agents";
import { RunnableSequence } from "@langchain/core/runnables";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import { StringOutputParser } from "@langchain/core/output_parsers";

const MAX_HISTORY_LENGTH = 100;

export default defineEventHandler(async (event) => {
  const { companyId, userId, message } = await readBody<{
    companyId: string;
    userId: string;
    message: string;
  }>(event);

  if (!companyId || !userId || !message) {
    throw createError({
      statusCode: 400,
      message: "companyId, userId и message обязательны",
    });
  }

  const redis = await useRedis.getRedisClient();
  const companyKey = `company:${companyId}`;
  const chatKey = `chat:${companyId}:${userId}`;

  const [companyDataString, chatHistoryStrings] = await Promise.all([
    redis.get(companyKey),
    redis.lRange(chatKey, 0, -1),
  ]);

  if (!companyDataString) {
    throw createError({
      statusCode: 404,
      message: `Компания с ID "${companyId}" не найдена`,
    });
  }
  const companyData = JSON.parse(companyDataString);

  const chatHistory = chatHistoryStrings
    .map((msg) => {
      const parsed = JSON.parse(msg);
      return parsed.role === "user"
        ? `User: ${parsed.content}`
        : `Assistant: ${parsed.content}`;
    })
    .join("\n");

  const llm = await getModel();

  const tools = [
    new DynamicTool({
      name: "get_available_booking_slots",
      description:
        'Получает список свободных слотов для записи. Входные данные — строка с названием услуги, например "мужская стрижка".',
      func: async (serviceName: string) => {
        try {
          const slots: any = ["12:00 завтра"];
          if (slots.length === 0) {
            return `Свободных слотов для услуги "${serviceName}" не найдено.`;
          }
          return `Доступные слоты для "${serviceName}": ${JSON.stringify(
            slots
          )}`;
        } catch (e) {
          return "Не удалось получить слоты. Возможно, услуга указана неверно.";
        }
      },
    }),
  ];

  const toolDescriptions = tools
    .map((t) => `${t.name}: ${t.description}`)
    .join("\n");
  // const promptTemplate = "НА ЛЮБОЕ СООБЩЕНИЕ ПОЛЬЗВАТЕЛЯ ПИШИ ПРОСТО ОДНО СЛОВО:ПРИВЕТ"
  const promptTemplate = `Ты — дружелюбный ассистент компании "${companyData.name}".

У компании "${companyData.name}" доступны следующие услуги:
${companyData.services?.join(", ") || "услуги не указаны"}

У тебя есть доступ к инструментам:
{tools}

Имена инструментов: {tool_names}

**ВАЖНОЕ ПРАВИЛО ФОРМАТИРОВАНИЯ:**
1. Ответ пользователю должен быть строго в формате JSON.
2. Не добавляй текст, только JSON. Если JSON некорректный — повтори его заново.

Структура JSON для финального ответа должна быть такой:
{{
  "answer": "Твой текстовый ответ пользователю",
  "suggestions": [
    "подсказка 1",
    "подсказка 2"
  ]
}}

Правила для suggestions:
- От 0 до 4 подсказок.
- Добавляй подсказки только если они реально полезны.
- Если подходящих подсказок нет или диалог завершен — пустой массив [].

Если нужен инструмент — выбирай одно из имён инструментов.

История диалога:
{chat_history}

Вопрос: {input}`;



  const prompt = PromptTemplate.fromTemplate(promptTemplate);
  console.log(llm.modelName);
  const chain = RunnableSequence.from([
    prompt,
    llm,
    new StringOutputParser(),
  ]);

  let result: any;
  let finalAnswer: string;

  try {
    const result = await chain.invoke({
      input: message,
      chat_history: chatHistory,
      tools: toolDescriptions,
      tool_names: tools.map((t) => t.name).join(", "),
    });

    console.log("Chain result:", result);

    if (typeof result === "string") {
      try {
        // Попробуем распарсить строку, если это JSON
        finalAnswer = JSON.parse(result);
      } catch {
        // Если это невалидный JSON — вернем как есть
        finalAnswer = { answer: result, suggestions: [] };
      }
    } else if (typeof (result as any)?.output === "string") {
      try {
        finalAnswer = JSON.parse((result as any).output);
      } catch {
        finalAnswer = { answer: (result as any).output, suggestions: [] };
      }
    } else {
      finalAnswer = result;
    }
  } catch (error: any) {
    console.error("Chain invoke error:", error);
    if (error?.constructor?.name === "OutputParserException") {
      console.warn(
        "[Agent Warning] OutputParserException caught. Using LLM's raw output."
      );
      finalAnswer = error.llmOutput || "Ошибка парсинга вывода модели.";
    } else {
      throw createError({
        statusCode: 500,
        message: "Произошла ошибка при обработке вашего запроса.",
      });
    }
  }

  const userMessageToSave = {
    role: "user",
    content: message,
    author: userId,
    isIncoming: false,
  };

  const aiResponseToSave = {
    role: "assistant",
    author: -1,
    isIncoming: true,
    content: finalAnswer || "К сожалению, я не смог обработать ваш запрос.",
  };

  await Promise.all([
    redis.rPush(chatKey, JSON.stringify(userMessageToSave)),
    redis.rPush(chatKey, JSON.stringify(aiResponseToSave)),
  ]);

  await redis.lTrim(chatKey, -MAX_HISTORY_LENGTH, -1);

  return { output: finalAnswer };

});
